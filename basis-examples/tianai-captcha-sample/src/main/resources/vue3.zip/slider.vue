<script lang="ts" setup>
import captchaApi from "@/api/captcha/captcha";
import { useCaptchaStore } from "@/store/modules/useCaptcha";
import { Close, Refresh } from "@element-plus/icons-vue";
import { CaptchaInfo, CaptchaTrack } from "@/api/captcha/types"
import {captcha} from "@/assets/config/config.json"

const useCaptcha = useCaptchaStore()

onMounted(() => {
  getImage();
  //打印日志
  useCaptcha.log = captcha.log
})

//验证码信息
const captchaInfo = ref<CaptchaInfo>({
  //背景图片
  backgroundImage: '',
  //滑块图片
  sliderImage: '',
  /** 随机值. */
  randomX: 0,
  //滑块高度
  sliderImageHeight: 0,
  //滑块宽度
  sliderImageWidth: 0,
  //类型
  type: 'SLIDER',
  x: 0,
  y: 0,
  data: {
    uuid: ''
  }
})

const initCaptChaTrank = (): CaptchaTrack => {
  return {
    bgImageWidth: 590,
    bgImageHeight: 360,
    sliderImageWidth: 110,
    sliderImageHeight: 360,
    startSlidingTime: new Date(),
    endSlidingTime: new Date(),
    trackList: [],
    data: {
      uuid: '',
      movePercent: 0,
    },
    startX: 0,
    startY: 0,
    startMove: false,
    moveX: 0,
    blockLeft: 0,
  }
}


const captchaTrack = ref<CaptchaTrack>(initCaptChaTrank())

const dialogPadding = ref(10)

const captchaStyle = reactive({
  '--bgImageWidth': captchaTrack.value.bgImageWidth + 'px',
  '--bgImageHeight': captchaTrack.value.bgImageHeight + 'px',
  '--sliderImageWidth': captchaTrack.value.sliderImageWidth + 'px',
  '--sliderImageHeight': captchaTrack.value.sliderImageHeight + 'px',
  '--dialogPadding': dialogPadding.value + 'px',
})


//获取图片
const getImage = () => {
  useCaptcha.loading = true;
  captchaApi.getCaptcha().then(res => {
    const data = res.data;
    captchaInfo.value = data ?? captchaInfo.value
    captchaTrack.value.data.uuid = captchaInfo.value.data.uuid
    useCaptcha.loading = false;
  }).catch(err => {
    ElMessage.error(err.msg)
  })
}

const emits = defineEmits(['validImage']);


//校验图片
const validImg = () => {
  printLog(`滑块抬起`, captchaTrack.value.data.movePercent)
  captchaApi.captchaValid({
    uuid: captchaTrack.value.data.uuid,
    movePercent: captchaTrack.value.data.movePercent,
    imageCaptchaTrack: captchaTrack.value
  }).then(res => {
    ElMessage.success(res.msg)
    useCaptcha.showSlider = false
    emits('validImage', true)
  }).catch(e => {
    ElMessage.error(e.msg)
    reset()
  })
}

//重新生成图片
const reset = () => {
  captchaTrack.value = initCaptChaTrank();
  getImage()
}

//按钮关闭事件
const close = () => {
  printLog("关闭按钮触发")
  useCaptcha.showSlider = false;
}

//输出日志
const printLog = (msg: String, ...optionalParams: Array<any>) => {
  if (useCaptcha.log) {
    if (optionalParams && optionalParams.length > 0) {
      console.info(
        `滑块验证码[${msg}]`,
        optionalParams.length === 1 ? optionalParams[0] : optionalParams
      )
    } else {
      console.info(`滑块验证码[${msg}]`);
    }
  }
}



/**
* 开始滑动
*/
const start = (e: MouseEvent) => {
  captchaTrack.value.startMove = true
  captchaTrack.value.startX = e.pageX
  captchaTrack.value.startY = e.pageY
  //轨迹
  captchaTrack.value.trackList.push({
    x: 0,
    y: 0,
    t: (new Date().getTime()) - (captchaTrack.value.startSlidingTime.getTime()),
    type: "down"
  })
  window.addEventListener("mousemove", move)
  window.addEventListener("mouseup", up)
}

/**
 * 滑块滑动事件
 */
const move = (e: MouseEvent) => {
  if (!captchaTrack.value.startMove) return
  const moveX = e.pageX - captchaTrack.value.startX;
  const movePercent = moveX / (captchaTrack.value.bgImageWidth - captchaTrack.value.sliderImageWidth)
  //移动最大值 最大值为(图片宽度-滑块宽度)
  const moveMax = captchaTrack.value.bgImageWidth - captchaTrack.value.sliderImageWidth;
  captchaTrack.value.trackList.push({
    x: e.pageX - captchaTrack.value.startX,
    y: e.pageY - captchaTrack.value.startY,
    t: new Date().getTime() - captchaTrack.value.startSlidingTime.getTime(),
    type: "move"
  })
  if (moveX <= 0) {
    captchaTrack.value.blockLeft = 0
    captchaTrack.value.moveX = 0
    captchaTrack.value.data.movePercent = 0
  } else if (moveX >= 0 && moveX <= moveMax) {
    captchaTrack.value.blockLeft = moveX
    captchaTrack.value.moveX = moveX
    captchaTrack.value.data.movePercent = movePercent
  } else if (moveX >= moveMax) {
    captchaTrack.value.blockLeft = moveMax
    captchaTrack.value.moveX = moveMax
    captchaTrack.value.data.movePercent = movePercent
  }
}

/**
 * 滑块鼠标抬起事件
 */
const up = (e: MouseEvent) => {
  if (!captchaTrack.value.startMove) return
  window.removeEventListener("mousemove", move);
  window.removeEventListener("mouseup", up);
  captchaTrack.value.startMove = false
  captchaTrack.value.endSlidingTime = new Date();
  captchaTrack.value.trackList.push({
    x: e.pageX - captchaTrack.value.startX,
    y: e.pageY - captchaTrack.value.startY,
    type: "up",
    t: (new Date().getTime() - captchaTrack.value.startSlidingTime.getTime())
  })
  validImg()
}

/**
 * 销毁事件
 */
const beforeDestroy = () => {
  window.removeEventListener("mousemove", move);
  window.removeEventListener("mouseup", up);
}

</script>


<template>
  <div class="dialog" :style="captchaStyle">
    <el-dialog v-model="useCaptcha.showSlider" @open="getImage" align-center center :show-close="false"
      :width="(captchaTrack.bgImageWidth + 2 * (dialogPadding)) + 'px'" destroy-on-close class="slider-dialog">
      <template #header>
        <div class="header">
          <div class="title">
            <span>请完成下列验证后继续</span>
          </div>
          <div class="button-group">
            <el-button :icon="Refresh" circle @click="reset"></el-button>
            <el-button :icon="Close" circle @click="close"></el-button>
          </div>
        </div>
      </template>
      <div class="img" v-loading="useCaptcha.loading" element-loading-text="loading..."
        element-loading-background="rgba(122, 122, 122, 0.1)">
        <div class="backgroup-img">
          <el-image class="inner-bg-img" :src="captchaInfo.backgroundImage">
          </el-image>
        </div>
        <div class="move-img" :style="{ left: `${captchaTrack.moveX}px` }">
          <el-image class="inner-mv-img" :src="captchaInfo.sliderImage">
          </el-image>
        </div>
      </div>
      <div class="slide">
        <div class="slider-mask" :style="{ width: `${captchaTrack.blockLeft}px` }">
          <div class="block" ref="block" @mousedown="start" :style="{ left: `${captchaTrack.blockLeft}px` }">
            <span class="yidun_slider_icon"></span>
          </div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>



<style lang="scss"  scoped>
.dialog {
  :deep(.slider-dialog) {

    .el-dialog__header,
    .el-dialog__body {
      padding: var(--dialogPadding);
      margin: 0;
    }
  }

  .inner-bg-img,
  .inner-mv-img {
    -moz-user-select: none;
    -webkit-user-select: none;
    -ms-user-select: none;
    -khtml-user-select: none;
    user-select: none;
  }

  .header {
    display: flex;
    flex-direction: row;
    justify-content: space-between;

    .title {
      line-height: 32px;
    }
  }

  .img {
    width: var(--bgImageWidth);
    height: var(--bgImageHeight);
    position: relative;

    img {
      width: 100%;
    }

    .backgroup-img {
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
    }

    .move-img {
      width: var(--sliderImageWidth);
      height: var(--sliderImageHeight);
      position: absolute;
      left: 0;
      top: 0;
    }
  }

  .slide {
    width: 100%;
    height: 47px;
    border: 1px solid #e4e7eb;
    background-color: #f7f9fa;
    box-sizing: border-box;
    position: relative;

    &::before {
      position: absolute;
      content: "按住左边按钮移动完成上方拼图";
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 12px;
      color: #999;
      width: 100%;
      height: 100%;
      text-indent: 50px;
    }

    .block {
      width: var(--sliderImageWidth);
      height: 45px;
      background-color: #fff;
      box-shadow: 0 0 3px rgba(0, 0, 0, 0.3);
      display: flex;
      justify-content: center;
      align-items: center;
      position: absolute;
      left: 0;
      top: 0;
      cursor: pointer;
      background-size: 30px;
      background-repeat: no-repeat;
      background-position: center;
    }
  }

  .block:hover {
    background-color: #1991fa;
  }

  .block:hover .yidun_slider_icon {
    background-image: url(https://cstaticdun.126.net//2.13.7/images/icon_light.4353d81.png);
    background-position: 0 0;
    background-size: 32px 544px;
  }



  .slider-mask {
    position: absolute;
    left: 0;
    top: 0;
    height: 45px;
    border: 0 solid #1991fa;
    background: #d1e9fe;
    border-radius: 2px;
  }

  .yidun_slider_icon {
    position: absolute;
    top: 50%;
    margin-top: -6px;
    left: 50%;
    margin-left: -6px;
    width: 14px;
    height: 10px;
    background-image: url(https://cstaticdun.126.net//2.13.7/images/icon_light.4353d81.png);
    background-position: 0 -13px;
    background-size: 32px 544px;
  }
}
</style>
