<script lang="ts" setup>
import "@/style/login.css"
import "@/api/login/login"
import loginApi from "@/api/login/login";
import globalConfig from "@/assets/config/config.json"
import { ElLoading, FormInstance, FormRules } from "element-plus";
import { useCaptchaStore } from "@/store/modules/useCaptcha"
import { retCode } from "@/utils/http/respConfig"
import { useNavigateStore } from "@/store/modules/useNavigate";
import { usePermissionStore } from "@/store/modules/usePermission";

const router = useRouter()

//验证码状态
const useCaptcha = useCaptchaStore()
//navigate
const useNavigate = useNavigateStore()
//权限
const usePermission = usePermissionStore()


//登录参数
const loginBody = reactive({
    username: "",
    password: "",
});


const ruleFormRef = ref<FormInstance>()

//参数校验
const formRules = reactive<FormRules>({
    username: [
        {
            required: true,
            message: "请输入用户名",
            trigger: 'blur'
        }
    ],
    password: [
        {
            required: true,
            message: "请输入密码",
            trigger: 'blur'
        }
    ]
})

//提交验证
const submit = async (ruleFormRef: FormInstance | undefined) => {
    if (!ruleFormRef) return
    await ruleFormRef.validate((valid, fields) => {
        if (valid) {
            //展示行为验证码
            useCaptcha.showSlider = true
        }
    })
}

//登录
const login = (result: Boolean = false) => {
    if (result) {
        //加载动画
        const loading = ElLoading.service({
            lock: true,
            text: 'Loading',
            background: 'rgba(0, 0, 0, 0.7)',
        })
        loginApi.login(loginBody).then(res => {
            const data = res.data
            if (res.code == retCode.SUCCESS) {
                const tokenPrefix = globalConfig.auth.tokenPrefix
                const tokenName = globalConfig.auth.tokenName
                ElMessage.success(res.msg)
                //重置pinia状态
                useNavigate.$reset()
                usePermission.$reset()
                //添加token
                localStorage.setItem(tokenName, tokenPrefix + " " + data.tokenValue)
                router.replace("/")
            } else {
                ElMessage.error(res.msg)
            }
        }).catch(err => {
            ElMessage.error(err.msg)
        });
        loading.close()
    }
}

</script>
<template>
    <div class="background">
        <div class="box">
            <h2>食堂信息管理系统</h2>
            <el-form :model="loginBody" label-position="top" :rules="formRules" ref="ruleFormRef">
                <div class="input-box">
                    <el-form-item label="用户名" prop="username">
                        <el-input @keyup.enter="submit(ruleFormRef)" v-model="loginBody.username">
                        </el-input>
                    </el-form-item>
                </div>
                <div class="input-box">
                    <el-form-item label="密码" prop="password">
                        <el-input @keyup.enter="submit(ruleFormRef)" v-model="loginBody.password" type="password"
                            show-password />
                    </el-form-item>
                </div>
            </el-form>
            <div class="btn-box">
                <div>
                    <button @click="submit(ruleFormRef)">登录</button>
                </div>
            </div>
        </div>
        <Slider @validImage="login" v-if="useCaptcha.showSlider"></Slider>
    </div>
</template>

<style lang="scss" scoped>
.background {
    .input-box {
        :deep(.el-input__suffix) {
            width: 22px;
        }
    }
}
</style>
